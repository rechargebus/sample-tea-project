# Sample Node.js Project

A Node.js project written using Express. EJS was used as the view engine.

# Installation

You need to write the following commands on the terminal screen so that you can run the project locally.

```sh
1. git clone git@github.com:acemilyalcin/sample-node-project.git
2. cd sample-node-project
3. npm install
4. npm start
```

The application is running on [localhost](http://localhost:3000).
